'''
******
******
******
******
******
'''

number_of_line = 6
number_of_star = 6

for i in range(1, number_of_line+1):
    for j in range(1, number_of_star+1):
        print("*", end='')
    
    print()


'''
*
**
***
****
*****
******
'''


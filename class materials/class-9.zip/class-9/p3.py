# continue

fruits = ['apple', 'mango', 'dragon', 'banana']

for fruit in fruits:
    if fruit == 'dragon':
        continue
    
    print("-------------")
    print(fruit)


[*] continue
[*] nested for loop
[*] finding even numbers (loop , stepping)
[*] star pattern
for i in range(1,11, 7):
    print(i)
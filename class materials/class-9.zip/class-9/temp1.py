count = 0
for i in range(1 , 5):
    print(i)
    count = count + 1

print(count)